package com.example.ds4mepper;

import android.system.Os;
import android.system.OsConstants;
import android.system.StructPollfd;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileDescriptor;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.io.RandomAccessFile;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

/**
 * Motor do DS4 Mapper. Roda como usuário "shell" (iniciado pelo Shizuku) e fica em segundo plano:
 *  1) cria um controle virtual em /dev/uhid;
 *  2) acha o controle PS4 real, pega ele com exclusividade (o Android deixa de vê-lo);
 *  3) lê os movimentos, aplica zona morta, curva, gatilhos, inversão e remapeamento;
 *  4) entrega o resultado ao controle virtual, que é o que os jogos enxergam.
 *
 * Configuração ao vivo: /data/local/tmp/ds4mepper.cfg (o app reescreve quando você mexe nos ajustes).
 * Se o motor parar por qualquer motivo, o bloqueio é solto sozinho e o PS4 volta ao normal.
 */
public class PadEngine {
    private static final String VNAME = "DS4Mapper Virtual Controller";
    private static final String CFG = "/data/local/tmp/ds4mepper.cfg";
    private static final String STATUS = "/data/local/tmp/ds4mepper.status";
    private static final String PIDFILE = "/data/local/tmp/ds4mepper.pid";

    private static final int EVIOCGRAB = 0x40044590; // _IOW('E', 0x90, int)
    private static final int UHID_DESTROY = 1;
    private static final int UHID_CREATE2 = 11;
    private static final int UHID_INPUT2 = 12;
    private static final int[] SIZES = {4376, 4380};
    private static int eventSize = 0;

    // Gamepad virtual: 4 eixos de 16 bits (X, Y, Z, Rz), 2 gatilhos (freio/acelerador),
    // 1 hat (D-pad) e 15 botões. Relatório de 13 bytes.
    private static final int[] DESC = {
        0x05, 0x01, 0x09, 0x05, 0xA1, 0x01,
        0x09, 0x30, 0x09, 0x31, 0x09, 0x32, 0x09, 0x35,
        0x16, 0x01, 0x80, 0x26, 0xFF, 0x7F,
        0x75, 0x10, 0x95, 0x04, 0x81, 0x02,
        0x05, 0x02, 0x09, 0xC5, 0x09, 0xC4,
        0x15, 0x00, 0x26, 0xFF, 0x00,
        0x75, 0x08, 0x95, 0x02, 0x81, 0x02,
        0x05, 0x01, 0x09, 0x39,
        0x15, 0x00, 0x25, 0x07,
        0x75, 0x04, 0x95, 0x01, 0x81, 0x42,
        0x05, 0x09, 0x19, 0x01, 0x29, 0x0F,
        0x15, 0x00, 0x25, 0x01,
        0x75, 0x01, 0x95, 0x0F, 0x81, 0x02,
        0x75, 0x01, 0x95, 0x05, 0x81, 0x03,
        0xC0
    };

    // Índice = código evdev do botão - 0x130. Valor = keycode do Android (0 = ignorar).
    private static final int[] PHYS_TO_ANDROID = {
        96,   // 0x130 BTN_SOUTH  (✕) -> BUTTON_A
        97,   // 0x131 BTN_EAST   (○) -> BUTTON_B
        0,    // 0x132
        100,  // 0x133 BTN_NORTH  (△) -> BUTTON_Y
        99,   // 0x134 BTN_WEST   (□) -> BUTTON_X
        0,    // 0x135
        102,  // 0x136 L1
        103,  // 0x137 R1
        104,  // 0x138 L2
        105,  // 0x139 R2
        109,  // 0x13a Share  -> SELECT
        108,  // 0x13b Options -> START
        110,  // 0x13c PS -> MODE
        106,  // 0x13d L3
        107   // 0x13e R3
    };

    // Keycodes que o controle virtual sabe enviar como botão.
    private static final int[] OUT_KEYS = {96, 97, 99, 100, 102, 103, 104, 105, 106, 107, 108, 109, 110};

    // ---- configuração (relida quando o arquivo muda) ----
    private static volatile boolean enabled = true;
    private static volatile float lZone = 0.10f, lCurve = 1.0f;
    private static volatile float rZone = 0.10f, rCurve = 1.0f;
    private static volatile float lSens = 1.0f, rSens = 1.0f;
    private static volatile float lMaxZ = 1.0f, rMaxZ = 1.0f;   // zona máxima
    private static volatile float ltStart = 0f, ltMax = 1f, ltCurve = 1f;
    private static volatile float rtStart = 0f, rtMax = 1f, rtCurve = 1f;
    private static volatile boolean invertY = false;
    private static String baseStatus = "";
    private static long lastCfgNs = 0;
    private static volatile int[] remapFrom = new int[0];
    private static volatile int[] remapTo = new int[0];
    private static long cfgStamp = -1;

    // ---- estado do controle real ----
    private static float lx = 127.5f, ly = 127.5f, rx = 127.5f, ry = 127.5f, lt = 0f, rt = 0f;
    private static int hx = 0, hy = 0;
    private static final boolean[] btn = new boolean[15];
    private static byte[] lastReport = null;

    private static String lastStatus = "";

    public static void main(String[] args) {
        RandomAccessFile uhid = null;
        FileDescriptor fd = null;
        try {
            write(PIDFILE, String.valueOf(android.os.Process.myPid()) + "\n");
            reloadConfig();
            status("INICIANDO");

            try {
                uhid = new RandomAccessFile("/dev/uhid", "rw");
            } catch (Exception e) {
                status("ERRO: não consegui abrir /dev/uhid: " + e);
                say("ERRO ao abrir /dev/uhid: " + e);
                return;
            }
            send(uhid, createEvent());
            say("Controle virtual criado.");
            Thread.sleep(800);
            sendReport(uhid, true);

            int sz = System.getProperty("os.arch", "").contains("64") ? 24 : 16;
            byte[] buf = new byte[sz * 64];
            StructPollfd[] p = new StructPollfd[] { new StructPollfd() };
            long nextScan = 0;

            while (true) {
                reloadConfig();
                if (!enabled) break;

                if (fd == null) {
                    long now = System.currentTimeMillis();
                    if (now < nextScan) {
                        Thread.sleep(200);
                        continue;
                    }
                    nextScan = now + 1500;
                    String path = findPad();
                    if (path == null) {
                        status("PROCURANDO o controle (ligue o PS4)");
                        continue;
                    }
                    FileDescriptor nfd;
                    try {
                        nfd = Os.open(path, OsConstants.O_RDONLY, 0);
                    } catch (Exception e) {
                        status("PROCURANDO o controle (ligue o PS4)");
                        continue;
                    }
                    String err = tryGrab(nfd);
                    if (err != null) {
                        try { Os.close(nfd); } catch (Exception ignored) { }
                        status("ERRO: " + err);
                        say("ERRO no bloqueio: " + err);
                        break;
                    }
                    fd = nfd;
                    resetState();
                    sendReport(uhid, true);
                    baseStatus = "ATIVO controle=" + path;
                    status(baseStatus);
                    say("Controle real bloqueado: " + path);
                    continue;
                }

                p[0].fd = fd;
                p[0].events = (short) OsConstants.POLLIN;
                p[0].revents = 0;
                int ready;
                try {
                    ready = Os.poll(p, 100);
                } catch (Exception e) {
                    ready = -1;
                }
                int rev = p[0].revents;
                boolean bad = ready < 0
                    || (rev & (OsConstants.POLLERR | OsConstants.POLLHUP | OsConstants.POLLNVAL)) != 0;

                if (!bad && ready > 0 && (rev & OsConstants.POLLIN) != 0) {
                    int n;
                    try {
                        n = Os.read(fd, buf, 0, buf.length);
                    } catch (Exception e) {
                        n = -1;
                    }
                    if (n <= 0) {
                        bad = true;
                    } else {
                        for (int off = 0; off + sz <= n; off += sz) {
                            int type = u16(buf, off + sz - 8);
                            int code = u16(buf, off + sz - 6);
                            int value = s32(buf, off + sz - 4);
                            handle(type, code, value, uhid);
                        }
                    }
                }

                if (bad) {
                    try { Os.close(fd); } catch (Exception ignored) { }
                    fd = null;
                    resetState();
                    sendReport(uhid, true);
                    nextScan = System.currentTimeMillis() + 500;
                    status("PROCURANDO o controle (ligue o PS4)");
                    say("Controle real desconectado.");
                }
            }
        } catch (Throwable t) {
            status("ERRO: " + t);
            say("FALHA: " + t);
        } finally {
            try { if (fd != null) Os.close(fd); } catch (Exception ignored) { }
            if (uhid != null) {
                try {
                    resetState();
                    sendReport(uhid, true);
                    send(uhid, simple(UHID_DESTROY));
                    Thread.sleep(200);
                } catch (Throwable ignored) { }
                try { uhid.close(); } catch (Exception ignored) { }
            }
            new File(PIDFILE).delete();
            if (!lastStatus.startsWith("ERRO")) status("PARADO");
            say("Motor encerrado.");
            System.exit(0);
        }
    }

    // ---------- entrada ----------

    private static void handle(int type, int code, int value, RandomAccessFile uhid) throws Exception {
        if (type == 3) { // EV_ABS
            switch (code) {
                case 0: lx = value; break;
                case 1: ly = value; break;
                case 2: lt = value; break;
                case 3: rx = value; break;
                case 4: ry = value; break;
                case 5: rt = value; break;
                case 16: hx = value; break;
                case 17: hy = value; break;
                default: break;
            }
        } else if (type == 1) { // EV_KEY
            int i = code - 0x130;
            if (i >= 0 && i < 15) {
                btn[i] = value != 0;
            }
        } else if (type == 0 && code == 0) { // EV_SYN / SYN_REPORT
            sendReport(uhid, false);
        }
    }

    private static void resetState() {
        lx = ly = rx = ry = 127.5f;
        lt = rt = 0f;
        hx = hy = 0;
        Arrays.fill(btn, false);
    }

    // ---------- processamento ----------

    private static int mapKey(int code) {
        int[] f = remapFrom;
        int[] t = remapTo;
        for (int i = 0; i < f.length; i++) if (f[i] == code) return t[i];
        return code;
    }

    private static float[] stick(float x, float y, float dz, float curve, float sens, float maxz) {
        float mag = (float) Math.hypot(x, y);
        if (mag <= dz || mag == 0f) return new float[] {0f, 0f};
        float span = Math.max(0.05f, maxz - dz);
        float scaled = Math.max(0f, Math.min(1f, (mag - dz) / span));
        float out = Math.min(1f, (float) Math.pow(scaled, curve) * sens);
        float ox = x / mag * out;
        float oy = y / mag * out;
        if (invertY) oy = -oy;
        return new float[] {ox, oy};
    }

    private static int trig(float raw, float start, float max, float curve) {
        float v = Math.max(0f, Math.min(1f, raw / 255f));
        float span = Math.max(0.05f, max - start);
        v = Math.max(0f, Math.min(1f, (v - start) / span));
        v = (float) Math.pow(v, curve);
        return Math.round(v * 255f);
    }

    private static int axis16(float v) {
        return Math.round(Math.max(-1f, Math.min(1f, v)) * 32767f);
    }

    private static int vbit(int key) {
        switch (key) {
            case 96: return 0;    // A
            case 97: return 1;    // B
            case 99: return 3;    // X
            case 100: return 4;   // Y
            case 102: return 6;   // L1
            case 103: return 7;   // R1
            case 104: return 8;   // L2
            case 105: return 9;   // R2
            case 109: return 10;  // SELECT
            case 108: return 11;  // START
            case 110: return 12;  // MODE
            case 106: return 13;  // L3
            case 107: return 14;  // R3
            default: return -1;
        }
    }

    private static byte[] buildReport() {
        float[] l = stick((lx - 127.5f) / 127.5f, (ly - 127.5f) / 127.5f, lZone, lCurve, lSens, lMaxZ);
        float[] r = stick((rx - 127.5f) / 127.5f, (ry - 127.5f) / 127.5f, rZone, rCurve, rSens, rMaxZ);

        boolean[] out = new boolean[512];
        for (int i = 0; i < 15; i++) {
            int k = PHYS_TO_ANDROID[i];
            if (btn[i] && k != 0) {
                int m = mapKey(k);
                if (m >= 0 && m < out.length) out[m] = true;
            }
        }
        int[] dp = {0, 0, 0, 0};
        if (hy < 0) dp[0] = 1;
        if (hy > 0) dp[1] = 1;
        if (hx < 0) dp[2] = 1;
        if (hx > 0) dp[3] = 1;
        for (int i = 0; i < 4; i++) {
            if (dp[i] != 0) {
                int m = mapKey(19 + i); // DPAD_UP, DOWN, LEFT, RIGHT
                if (m >= 0 && m < out.length) out[m] = true;
            }
        }

        boolean u = out[19], d = out[20], le = out[21], ri = out[22];
        int hat = 8;
        if (u && ri) hat = 1;
        else if (d && ri) hat = 3;
        else if (d && le) hat = 5;
        else if (u && le) hat = 7;
        else if (u) hat = 0;
        else if (ri) hat = 2;
        else if (d) hat = 4;
        else if (le) hat = 6;

        int buttons = 0;
        for (int k : OUT_KEYS) {
            if (out[k]) {
                int b = vbit(k);
                if (b >= 0) buttons |= 1 << b;
            }
        }
        int tail = hat | (buttons << 4);

        ByteBuffer b = ByteBuffer.allocate(13).order(ByteOrder.LITTLE_ENDIAN);
        b.putShort((short) axis16(l[0]));
        b.putShort((short) axis16(l[1]));
        b.putShort((short) axis16(r[0]));
        b.putShort((short) axis16(r[1]));
        b.put((byte) trig(lt, ltStart, ltMax, ltCurve));
        b.put((byte) trig(rt, rtStart, rtMax, rtCurve));
        b.put((byte) (tail & 0xFF));
        b.put((byte) ((tail >> 8) & 0xFF));
        b.put((byte) ((tail >> 16) & 0xFF));
        return b.array();
    }

    private static void sendReport(RandomAccessFile uhid, boolean force) throws Exception {
        byte[] data = buildReport();
        if (!force && lastReport != null && Arrays.equals(lastReport, data)) return;
        lastReport = data;
        ByteBuffer b = ByteBuffer.allocate(4 + 2 + data.length).order(ByteOrder.LITTLE_ENDIAN);
        b.putInt(UHID_INPUT2);
        b.putShort((short) data.length);
        b.put(data);
        send(uhid, b.array());
    }

    // ---------- controle virtual (uhid) ----------

    private static void send(RandomAccessFile f, byte[] data) throws Exception {
        if (eventSize != 0) {
            f.write(pad(data, eventSize));
            return;
        }
        Exception last = null;
        for (int s : SIZES) {
            try {
                f.write(pad(data, s));
                eventSize = s;
                return;
            } catch (Exception e) {
                last = e;
            }
        }
        throw last;
    }

    private static byte[] pad(byte[] d, int size) {
        byte[] r = new byte[size];
        System.arraycopy(d, 0, r, 0, Math.min(d.length, size));
        return r;
    }

    private static byte[] simple(int type) {
        ByteBuffer b = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN);
        b.putInt(type);
        return b.array();
    }

    private static void putStr(ByteBuffer b, String s, int len) {
        byte[] bytes = s.getBytes(StandardCharsets.UTF_8);
        int start = b.position();
        b.put(bytes, 0, Math.min(bytes.length, len - 1));
        b.position(start + len);
    }

    private static byte[] createEvent() {
        ByteBuffer b = ByteBuffer.allocate(4376).order(ByteOrder.LITTLE_ENDIAN);
        b.putInt(UHID_CREATE2);
        putStr(b, VNAME, 128);
        putStr(b, "ds4mepper/engine0", 64);
        putStr(b, "", 64);
        b.putShort((short) DESC.length);
        b.putShort((short) 3);      // BUS_USB
        b.putInt(0x1209);           // vendor (faixa de testes)
        b.putInt(0x7A02);           // product
        b.putInt(1);                // version
        b.putInt(0);                // country
        for (int d : DESC) b.put((byte) d);
        return b.array();
    }

    // ---------- controle real ----------

    /**
     * Linha "name:" do getevent que é o controle principal. Por Bluetooth o nome é "Wireless Controller";
     * por USB o Linux costuma chamar de "Sony Interactive Entertainment Wireless Controller".
     * Os aparelhos auxiliares (Motion Sensors e Touchpad) são ignorados.
     */
    private static boolean isPadNameLine(String t) {
        if (!t.startsWith("name:")) return false;
        String n = t.toLowerCase(java.util.Locale.ROOT);
        return n.contains("wireless controller")
            && !n.contains("motion sensors")
            && !n.contains("touchpad");
    }

    private static String findPad() {
        try {
            java.lang.Process pr = new ProcessBuilder("getevent", "-pl").redirectErrorStream(true).start();
            BufferedReader br = new BufferedReader(new InputStreamReader(pr.getInputStream()));
            String path = null;
            String found = null;
            String line;
            while ((line = br.readLine()) != null) {
                String t = line.trim();
                if (t.startsWith("add device")) {
                    int i = t.indexOf(": ");
                    path = i >= 0 ? t.substring(i + 2).trim() : null;
                } else if (isPadNameLine(t)) {
                    found = path;
                    break;
                }
            }
            pr.destroy();
            return found;
        } catch (Exception e) {
            return null;
        }
    }

    private static String tryGrab(FileDescriptor fd) {
        try {
            Object os = Class.forName("libcore.io.Libcore").getField("os").get(null);
            Class<?> osCls = Class.forName("libcore.io.Os");
            try {
                Method m = osCls.getMethod("ioctlInt", FileDescriptor.class, int.class);
                m.invoke(os, fd, EVIOCGRAB);
                return null;
            } catch (NoSuchMethodException e1) {
                Class<?> ref = Class.forName("android.system.Int32Ref");
                Object arg = ref.getConstructor(int.class).newInstance(1);
                Method m = osCls.getMethod("ioctlInt", FileDescriptor.class, int.class, ref);
                m.invoke(os, fd, EVIOCGRAB, arg);
                return null;
            }
        } catch (InvocationTargetException e) {
            return "o sistema recusou o bloqueio: " + e.getCause();
        } catch (Throwable t) {
            return "bloqueio indisponível neste Android: " + t;
        }
    }

    private static int u16(byte[] b, int o) {
        return (b[o] & 0xFF) | ((b[o + 1] & 0xFF) << 8);
    }

    private static int s32(byte[] b, int o) {
        return (b[o] & 0xFF) | ((b[o + 1] & 0xFF) << 8) | ((b[o + 2] & 0xFF) << 16) | ((b[o + 3] & 0xFF) << 24);
    }

    // ---------- configuração e status ----------

    private static void reloadConfig() {
        long nowCfg = System.nanoTime();
        if (lastCfgNs != 0 && nowCfg - lastCfgNs < 150_000_000L) return;   // confere o arquivo a cada 150 ms
        lastCfgNs = nowCfg;
        File f = new File(CFG);
        long stamp = f.exists() ? f.lastModified() * 31 + f.length() : 0;
        if (stamp == cfgStamp) return;
        cfgStamp = stamp;
        if (!f.exists()) return;
        boolean en = true;
        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String line;
            while ((line = br.readLine()) != null) {
                int i = line.indexOf('=');
                if (i < 0) continue;
                String k = line.substring(0, i).trim();
                String v = line.substring(i + 1).trim();
                try {
                    switch (k) {
                        case "enabled": en = v.equals("1"); break;
                        case "lzone": lZone = zone(v); break;
                        case "rzone": rZone = zone(v); break;
                        case "lcurve": lCurve = curveOf(v); break;
                        case "rcurve": rCurve = curveOf(v); break;
                        case "lsens": lSens = clamp(v, 0.3f, 3f); break;
                        case "rsens": rSens = clamp(v, 0.3f, 3f); break;
                        case "lmaxz": lMaxZ = clamp(v, 0.5f, 1f); break;
                        case "rmaxz": rMaxZ = clamp(v, 0.5f, 1f); break;
                        case "ltstart": ltStart = clamp(v, 0f, 0.6f); break;
                        case "rtstart": rtStart = clamp(v, 0f, 0.6f); break;
                        case "ltmax": ltMax = clamp(v, 0.3f, 1f); break;
                        case "rtmax": rtMax = clamp(v, 0.3f, 1f); break;
                        case "ltcurve": ltCurve = curveOf(v); break;
                        case "rtcurve": rtCurve = curveOf(v); break;
                        case "invertY": invertY = v.equals("1"); break;
                        case "remap": parseRemap(v); break;
                        default: break;
                    }
                } catch (Exception ignored) { }
            }
        } catch (Exception ignored) {
            return;
        }
        enabled = en;
    }

    private static float clamp(String v, float lo, float hi) {
        return Math.max(lo, Math.min(hi, Float.parseFloat(v)));
    }

    private static float zone(String v) { return clamp(v, 0f, 0.5f); }

    private static float curveOf(String v) { return clamp(v, 0.1f, 5f); }

    private static void parseRemap(String v) {
        String[] parts = v.isEmpty() ? new String[0] : v.split(",");
        int[] from = new int[parts.length];
        int[] to = new int[parts.length];
        int n = 0;
        for (String part : parts) {
            String[] ab = part.split(":");
            if (ab.length != 2) continue;
            try {
                from[n] = Integer.parseInt(ab[0].trim());
                to[n] = Integer.parseInt(ab[1].trim());
                n++;
            } catch (Exception ignored) { }
        }
        remapFrom = Arrays.copyOf(from, n);
        remapTo = Arrays.copyOf(to, n);
    }

    private static void write(String path, String text) {
        try (FileOutputStream o = new FileOutputStream(path)) {
            o.write(text.getBytes(StandardCharsets.UTF_8));
        } catch (Exception ignored) { }
    }

    private static void status(String s) {
        if (s.equals(lastStatus)) return;
        lastStatus = s;
        write(STATUS, s + "\n");
    }

    private static void say(String s) {
        System.out.println(s);
        System.out.flush();
    }
}
