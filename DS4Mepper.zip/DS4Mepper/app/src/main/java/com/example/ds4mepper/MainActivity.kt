package com.example.ds4mepper

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.hardware.input.InputManager
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PointF
import android.graphics.LinearGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.usb.UsbManager
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.ViewTreeObserver
import android.view.animation.DecelerateInterpolator
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.CompoundButton
import android.widget.FrameLayout
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import kotlin.math.max
import kotlin.concurrent.thread
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    private enum class Step { IDLE, SOURCE, TARGET }

    private lateinit var store: ProfileStore
    private lateinit var profile: Profile
    private lateinit var pad: GamepadView
    private lateinit var status: TextView
    private lateinit var remapBtn: Button
    private lateinit var remapInfo: TextView
    private lateinit var panel: LinearLayout
    private lateinit var ledSwatch: TextView
    private lateinit var ledInfo: TextView
    private val ledBars = arrayOfNulls<SeekBar>(3)
    private lateinit var rootFrame: FrameLayout
    private lateinit var popupHost: FrameLayout
    private lateinit var panelPerfis: LinearLayout
    private lateinit var panelLed: LinearLayout
    private lateinit var panelAdv: LinearLayout
    private lateinit var tabViews: Array<ScrollView>
    private lateinit var tabLabels: Array<TextView>
    private var currentTab = 0
    // Painel de analógico aberto (null = nenhum). Os ajustes valem na hora; "Salvar" grava no perfil.
    private var stickTag: String? = null
    private var stickCfgOpen: StickCfg? = null
    private var stickBackup: StickCfg? = null
    private val livePushRunnable = Runnable { pushEngine() }
    private lateinit var connPill: TextView
    private lateinit var devName: TextView
    private lateinit var devState: TextView
    private val colorDots = ArrayList<View>()
    private var rainbowDot: View? = null
    private val dotPalette = listOf(
        Color.rgb(0, 80, 255), Color.rgb(0, 200, 255), Color.rgb(160, 0, 255), Color.rgb(255, 0, 200),
        Color.rgb(255, 0, 0), Color.rgb(255, 150, 0), Color.rgb(230, 255, 0), Color.rgb(0, 255, 80)
    )
    private var engineText = "Motor: verificando..."
    private var device: InputDevice? = null

    // Motor (roda em segundo plano pelo Shizuku)
    private lateinit var engineStatus: TextView
    private var engineOn = false
    private val handler = Handler(Looper.getMainLooper())
    private val statusTick = object : Runnable {
        override fun run() {
            thread {
                val s = PadEngineCtl.status()
                runOnUiThread { applyEngineStatus(s); refreshConn() }
            }
            handler.postDelayed(this, 2500)
        }
    }
    private val padListener = object : InputManager.InputDeviceListener {
        override fun onInputDeviceAdded(deviceId: Int) {
            // O DS4 volta à cor padrão ao reconectar: espera um pouco e aplica de novo.
            handler.postDelayed({
                refreshConn()
                if (profile.led) applyLed()
            }, 800)
        }
        override fun onInputDeviceRemoved(deviceId: Int) { refreshConn() }
        override fun onInputDeviceChanged(deviceId: Int) { refreshConn() }
    }
    private val permListener = Shizuku.OnRequestPermissionResultListener { _, result ->
        if (result == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            runOnUiThread { startEngine() }
        }
    }

    // Remapeamento
    private var step = Step.IDLE
    private var source = 0

    // O D-pad do DS4 chega como eixo (hat). Eu converto em botões virtuais para poder remapear.
    private var lastHx = 0f
    private var lastHy = 0f
    private val hatHeld = mutableSetOf<Int>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = ProfileStore(this)
        profile = store.load(store.activeName())

        pad = GamepadView(this).also { it.profile = profile }
        pad.onTap = { tag -> onPadTap(tag) }
        pad.onStickGesture = { tag -> if (step == Step.IDLE) showStickCard(tag == "LS") }

        panelPerfis = tabColumn()
        panelLed = tabColumn()
        panelAdv = tabColumn()
        panel = panelAdv

        buildUi()
        buildPanel()
        setContentView(rootFrame)
        Shizuku.addRequestPermissionResultListener(permListener)
        (getSystemService(Context.INPUT_SERVICE) as InputManager).registerInputDeviceListener(padListener, handler)
        if (profile.led) applyLed()
        refreshConn()
    }

    // ------------------------------------------------------------------
    //  Visual neon
    // ------------------------------------------------------------------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun gradient(colors: IntArray, radiusDp: Int, withStroke: Boolean = true): GradientDrawable {
        val g = GradientDrawable(GradientDrawable.Orientation.TL_BR, colors)
        g.cornerRadius = dp(radiusDp).toFloat()
        if (withStroke) g.setStroke(dp(1), Color.rgb(76, 52, 160))
        return g
    }

    private fun tabColumn(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.setPadding(dp(12), dp(10), dp(12), dp(14))
        return l
    }

    private fun heading(t: String): TextView {
        val v = label(t)
        v.tag = "h"
        v.textSize = 16f
        return v
    }

    /** Pinta botões, textos, barras e listas do painel no estilo neon. */
    private fun styleTree(view: View) {
        when (view) {
            is CompoundButton -> {
                view.setTextColor(Color.rgb(225, 226, 245))
                view.textSize = 13f
            }
            is Button -> {
                if (view.tag == "danger") {
                    view.background = gradient(intArrayOf(Color.rgb(120, 20, 50), Color.rgb(70, 12, 36)), 12)
                    view.setTextColor(Color.rgb(255, 140, 160))
                } else {
                    view.background = gradient(intArrayOf(Color.rgb(103, 35, 218), Color.rgb(48, 75, 220)), 12)
                    view.setTextColor(Color.WHITE)
                }
                view.textSize = 13f
                view.typeface = Typeface.DEFAULT_BOLD
                view.minHeight = dp(40)
                view.minimumHeight = dp(40)
                view.setPadding(dp(10), dp(6), dp(10), dp(6))
                view.setAllCaps(false)
            }
            is TextView -> {
                if (view.tag == "h") {
                    view.setTextColor(Color.rgb(204, 177, 255))
                    view.typeface = Typeface.DEFAULT_BOLD
                } else if (view.currentTextColor == Color.WHITE) {
                    view.setTextColor(Color.rgb(225, 226, 245))
                }
            }
            is SeekBar -> {
                view.progressTintList = ColorStateList.valueOf(Color.rgb(135, 65, 255))
                view.thumbTintList = ColorStateList.valueOf(Color.rgb(50, 160, 255))
                view.progressBackgroundTintList = ColorStateList.valueOf(Color.rgb(65, 62, 90))
            }
            is Spinner -> {
                view.background = gradient(intArrayOf(Color.rgb(44, 26, 104), Color.rgb(28, 38, 104)), 12)
            }
        }
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) styleTree(view.getChildAt(i))
        }
    }

    private fun brandText(size: Float): TextView {
        val t = TextView(this)
        t.text = "DS4 Mapper"
        t.textSize = size
        t.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD_ITALIC)
        t.setTextColor(Color.WHITE)
        t.paint.shader = LinearGradient(
            0f, 0f, dp((size * 6.2f).toInt()).toFloat(), 0f,
            intArrayOf(Color.WHITE, Color.rgb(196, 120, 255), Color.rgb(60, 170, 255)),
            null, Shader.TileMode.CLAMP
        )
        return t
    }

    private fun pillBg(): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(Color.argb(160, 14, 16, 44))
        g.cornerRadius = dp(28).toFloat()
        g.setStroke(dp(2), Color.rgb(46, 160, 255))
        return g
    }

    private fun iconButton(icon: String, name: String, onClick: () -> Unit): LinearLayout {
        val b = LinearLayout(this)
        b.orientation = LinearLayout.VERTICAL
        b.gravity = Gravity.CENTER
        b.background = gradient(intArrayOf(Color.rgb(26, 24, 66), Color.rgb(16, 18, 46)), 12)
        val i = TextView(this)
        i.text = icon
        i.textSize = 17f
        i.gravity = Gravity.CENTER
        i.setTextColor(Color.WHITE)
        val n = TextView(this)
        n.text = name
        n.textSize = 10f
        n.gravity = Gravity.CENTER
        n.setTextColor(Color.rgb(210, 200, 255))
        b.addView(i)
        b.addView(n)
        b.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(dp(62), dp(52))
        lp.marginStart = dp(8)
        b.layoutParams = lp
        return b
    }

    private fun buildTopBar(): LinearLayout {
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL

        val logo = TextView(this)
        logo.text = "🎮"
        logo.textSize = 24f
        logo.gravity = Gravity.CENTER
        logo.background = gradient(intArrayOf(Color.rgb(110, 40, 230), Color.rgb(30, 120, 255)), 14, false)
        val llp = LinearLayout.LayoutParams(dp(48), dp(48))
        llp.marginEnd = dp(10)
        bar.addView(logo, llp)

        val titleBox = LinearLayout(this)
        titleBox.orientation = LinearLayout.VERTICAL
        titleBox.addView(brandText(26f))
        val sub = TextView(this)
        sub.text = "Configure seu controle do jeito que quiser"
        sub.textSize = 11f
        sub.setTextColor(Color.rgb(190, 180, 235))
        titleBox.addView(sub)
        bar.addView(titleBox)

        connPill = TextView(this)
        connPill.textSize = 13f
        connPill.setTextColor(Color.WHITE)
        connPill.gravity = Gravity.CENTER
        connPill.setPadding(dp(18), dp(8), dp(18), dp(8))
        connPill.background = pillBg()
        val mid = LinearLayout(this)
        mid.gravity = Gravity.CENTER
        mid.addView(connPill)
        bar.addView(mid, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        bar.addView(iconButton("⚙", "Ajustes") { selectTab(2) })
        bar.addView(iconButton("💾", "Perfis") { selectTab(0) })
        bar.addView(iconButton("🎨", "LED") { selectTab(1) })
        bar.addView(iconButton("ℹ", "Info") { showInfo() })
        return bar
    }

    private fun dotBg(color: Int, selected: Boolean): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(color)
        if (selected) g.setStroke(dp(3), Color.WHITE) else g.setStroke(dp(1), Color.argb(120, 255, 255, 255))
        return g
    }

    private fun buildBottomBar(): LinearLayout {
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(dp(16), 0, dp(16), 0)
        bar.background = gradient(intArrayOf(Color.argb(210, 20, 16, 52), Color.argb(210, 12, 14, 38)), 16)

        val ico = TextView(this)
        ico.text = "🎮"
        ico.textSize = 26f
        val ilp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        ilp.marginEnd = dp(10)
        bar.addView(ico, ilp)

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        devName = TextView(this)
        devName.text = "Nenhum controle"
        devName.textSize = 14f
        devName.setTypeface(devName.typeface, Typeface.BOLD)
        devName.setTextColor(Color.WHITE)
        devState = TextView(this)
        devState.text = "● Desconectado"
        devState.textSize = 12f
        devState.setTextColor(Color.rgb(190, 185, 225))
        box.addView(devName)
        box.addView(devState)
        bar.addView(box)

        val mid = LinearLayout(this)
        mid.gravity = Gravity.CENTER
        mid.addView(brandText(22f))
        bar.addView(mid, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        val right = LinearLayout(this)
        right.orientation = LinearLayout.VERTICAL
        right.gravity = Gravity.END
        val ledLabel = TextView(this)
        ledLabel.text = "LED do Controle"
        ledLabel.textSize = 11f
        ledLabel.setTextColor(Color.rgb(210, 200, 255))
        right.addView(ledLabel)
        val dots = LinearLayout(this)
        dots.orientation = LinearLayout.HORIZONTAL
        for (col in dotPalette) {
            val d = View(this)
            d.setOnClickListener { setLedColor(Color.red(col), Color.green(col), Color.blue(col)) }
            colorDots.add(d)
            val dlp = LinearLayout.LayoutParams(dp(26), dp(26))
            dlp.setMargins(dp(4), dp(2), dp(4), dp(2))
            dots.addView(d, dlp)
        }
        val rb = View(this)
        rb.setOnClickListener { selectTab(1) }
        val rlp = LinearLayout.LayoutParams(dp(26), dp(26))
        rlp.setMargins(dp(4), dp(2), dp(4), dp(2))
        dots.addView(rb, rlp)
        rainbowDot = rb
        right.addView(dots)
        bar.addView(right)
        return bar
    }

    private fun refreshDots() {
        for (i in colorDots.indices) {
            val col = dotPalette[i]
            val sel = profile.led && Color.rgb(profile.ledR, profile.ledG, profile.ledB) == col
            colorDots[i].background = dotBg(col, sel)
        }
        val g = GradientDrawable()
        g.setShape(GradientDrawable.OVAL)
        g.setGradientType(GradientDrawable.SWEEP_GRADIENT)
        g.setColors(intArrayOf(Color.RED, Color.YELLOW, Color.GREEN, Color.CYAN, Color.BLUE, Color.MAGENTA, Color.RED))
        g.setStroke(dp(1), Color.argb(150, 255, 255, 255))
        rainbowDot?.background = g
    }

    private fun tabLabel(t: String, idx: Int): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = 13f
        v.gravity = Gravity.CENTER
        v.typeface = Typeface.DEFAULT_BOLD
        v.setOnClickListener { selectTab(idx) }
        return v
    }

    private fun selectTab(i: Int) {
        currentTab = i
        for (k in tabViews.indices) tabViews[k].visibility = if (k == i) View.VISIBLE else View.GONE
        for (k in tabLabels.indices) {
            val on = k == i
            if (on) {
                tabLabels[k].background = gradient(intArrayOf(Color.rgb(116, 44, 236), Color.rgb(62, 82, 238)), 12, false)
                tabLabels[k].setTextColor(Color.WHITE)
            } else {
                tabLabels[k].background = null
                tabLabels[k].setTextColor(Color.rgb(170, 165, 205))
            }
        }
    }

    private fun buildUi() {
        rootFrame = FrameLayout(this)
        rootFrame.background = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.rgb(5, 6, 22), Color.rgb(20, 9, 44), Color.rgb(6, 8, 28))
        )

        val column = LinearLayout(this)
        column.orientation = LinearLayout.VERTICAL
        column.setPadding(dp(14), dp(8), dp(14), dp(8))
        column.addView(buildTopBar(), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(64)))

        val middle = LinearLayout(this)
        middle.orientation = LinearLayout.HORIZONTAL

        val padFrame = FrameLayout(this)
        padFrame.background = gradient(intArrayOf(Color.argb(150, 14, 14, 40), Color.argb(150, 8, 10, 30)), 20)
        padFrame.addView(pad, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        popupHost = FrameLayout(this)
        popupHost.visibility = View.GONE
        padFrame.addView(popupHost, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val plp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 2.2f)
        plp.topMargin = dp(8)
        plp.bottomMargin = dp(8)
        plp.marginEnd = dp(10)
        middle.addView(padFrame, plp)

        val right = LinearLayout(this)
        right.orientation = LinearLayout.VERTICAL
        right.background = gradient(intArrayOf(Color.argb(190, 20, 17, 46), Color.argb(190, 12, 14, 34)), 20)
        right.setPadding(dp(6), dp(6), dp(6), dp(6))
        val tabs = LinearLayout(this)
        tabs.orientation = LinearLayout.HORIZONTAL
        tabLabels = arrayOf(tabLabel("👤  Perfis", 0), tabLabel("💡  LED", 1), tabLabel("🎚  Avançado", 2))
        for (t in tabLabels) tabs.addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        right.addView(tabs, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)))
        val host = FrameLayout(this)
        tabViews = arrayOf(ScrollView(this), ScrollView(this), ScrollView(this))
        tabViews[0].addView(panelPerfis)
        tabViews[1].addView(panelLed)
        tabViews[2].addView(panelAdv)
        for (sv in tabViews) host.addView(sv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        right.addView(host, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val rlp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
        rlp.topMargin = dp(8)
        rlp.bottomMargin = dp(8)
        middle.addView(right, rlp)

        column.addView(middle, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        column.addView(buildBottomBar(), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(60)))
        rootFrame.addView(column, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    // ------------------------------------------------------------------
    //  Conexão (barra de cima e de baixo)
    // ------------------------------------------------------------------

    private fun connectedPads(): List<InputDevice> =
        InputDevice.getDeviceIds().toList().mapNotNull { InputDevice.getDevice(it) }.filter { d ->
            val s = d.sources
            ((s and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
                (s and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK) &&
                d.name != PadEngineCtl.DEVICE_NAME
        }

    private fun hasSonyUsb(): Boolean = try {
        (getSystemService(Context.USB_SERVICE) as UsbManager).deviceList.values.any { it.vendorId == 0x054C }
    } catch (t: Throwable) {
        false
    }

    private fun refreshConn() {
        val pads = connectedPads()
        val ok = pads.isNotEmpty()
        val txt = when {
            !ok -> "Aguardando controle"
            hasSonyUsb() -> "Conectado via USB"
            else -> "Conectado via Bluetooth"
        }
        val dotColor = if (ok) Color.rgb(60, 230, 120) else Color.rgb(150, 150, 175)
        val sp = SpannableString("$txt   ●")
        sp.setSpan(ForegroundColorSpan(dotColor), sp.length - 1, sp.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        connPill.text = sp
        val p = pads.firstOrNull()
        devName.text = when {
            p == null -> "Nenhum controle"
            p.name.contains("Wireless Controller") -> "DualShock 4"
            else -> p.name
        }
        val ds = SpannableString(if (ok) "● Conectado" else "● Desconectado")
        ds.setSpan(ForegroundColorSpan(dotColor), 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        devState.text = ds
    }

    private fun showInfo() {
        AlertDialog.Builder(this)
            .setTitle("DS4 Mapper")
            .setMessage(
                "Versão 1.2\n\n" + engineText +
                    "\n\nToque no controle desenhado para ajustar cada analógico, gatilho ou botão."
            )
            .setPositiveButton("Diagnóstico") { _, _ -> startActivity(Intent(this, DiagActivity::class.java)) }
            .setNegativeButton("Fechar", null)
            .show()
    }

    // ------------------------------------------------------------------
    //  Cartões que abrem ao tocar no controle desenhado
    // ------------------------------------------------------------------

    private fun keyForTag(tag: String): Int? = when (tag) {
        "L1" -> KeyEvent.KEYCODE_BUTTON_L1
        "R1" -> KeyEvent.KEYCODE_BUTTON_R1
        "L2" -> KeyEvent.KEYCODE_BUTTON_L2
        "R2" -> KeyEvent.KEYCODE_BUTTON_R2
        "UP" -> KeyEvent.KEYCODE_DPAD_UP
        "DOWN" -> KeyEvent.KEYCODE_DPAD_DOWN
        "LEFT" -> KeyEvent.KEYCODE_DPAD_LEFT
        "RIGHT" -> KeyEvent.KEYCODE_DPAD_RIGHT
        "Y" -> KeyEvent.KEYCODE_BUTTON_Y
        "A" -> KeyEvent.KEYCODE_BUTTON_A
        "X" -> KeyEvent.KEYCODE_BUTTON_X
        "B" -> KeyEvent.KEYCODE_BUTTON_B
        "SELECT" -> KeyEvent.KEYCODE_BUTTON_SELECT
        "START" -> KeyEvent.KEYCODE_BUTTON_START
        "MODE" -> KeyEvent.KEYCODE_BUTTON_MODE
        "LS" -> KeyEvent.KEYCODE_BUTTON_THUMBL
        "RS" -> KeyEvent.KEYCODE_BUTTON_THUMBR
        else -> null
    }

    private fun onPadTap(tag: String) {
        val code = keyForTag(tag)
        if (step != Step.IDLE) {
            // Durante o "remapear", tocar no desenho escolhe o botão.
            if (code != null) handleRemapPress(code)
            return
        }
        when (tag) {
            "LS" -> showStickCard(true)
            "RS" -> showStickCard(false)
            "L2" -> showTriggerCard(true)
            "R2" -> showTriggerCard(false)
            else -> if (code != null) showButtonCard(code)
        }
    }

    private fun closeCard() {
        popupHost.removeAllViews()
        popupHost.visibility = View.GONE
        store.save(profile)
        pushEngine()
        buildPanel()
        pad.invalidate()
    }

    private fun showCard(title: String, left: Boolean, build: (LinearLayout) -> Unit) {
        if (stickCfgOpen != null) closeStickCard(false)
        popupHost.removeAllViews()
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(14), dp(10), dp(14), dp(12))
        card.background = gradient(intArrayOf(Color.rgb(24, 20, 56), Color.rgb(14, 16, 38)), 18)

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val ttl = heading(title)
        head.addView(ttl, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val x = TextView(this)
        x.text = "✕"
        x.textSize = 20f
        x.setTextColor(Color.rgb(200, 190, 255))
        x.setPadding(dp(12), dp(2), dp(4), dp(2))
        x.setOnClickListener { closeCard() }
        head.addView(x)
        card.addView(head)

        build(card)
        styleTree(card)

        val lp = FrameLayout.LayoutParams(
            dp(330), ViewGroup.LayoutParams.WRAP_CONTENT,
            (if (left) Gravity.START else Gravity.END) or Gravity.BOTTOM
        )
        lp.setMargins(dp(14), dp(14), dp(14), dp(18))
        popupHost.addView(card, lp)
        popupHost.visibility = View.VISIBLE
    }

    private fun cardButtons(onReset: () -> Unit): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.setPadding(0, dp(8), 0, 0)
        val reset = Button(this)
        reset.text = "↺  Redefinir"
        reset.setOnClickListener { onReset() }
        val ok = Button(this)
        ok.text = "✔  Aplicar"
        ok.setOnClickListener { closeCard() }
        val lp1 = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        lp1.marginEnd = dp(6)
        row.addView(reset, lp1)
        row.addView(ok, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        return row
    }

    // ------------------------------------------------------------------
    //  Painel do analógico: aparece ao lado do analógico tocado
    // ------------------------------------------------------------------

    /** Aplica no motor depois que o dedo para de mexer (evita mandar centenas de comandos). */
    private fun livePush() {
        handler.removeCallbacks(livePushRunnable)
        handler.postDelayed(livePushRunnable, 150)
    }

    private fun compactSlider(
        name: String, lo: Float, hi: Float,
        get: () -> Float, set: (Float) -> Unit, fmt: (Float) -> String
    ): LinearLayout {
        val title = TextView(this)
        title.text = name
        title.textSize = 11f
        title.setTextColor(Color.WHITE)
        val value = TextView(this)
        value.text = fmt(get())
        value.textSize = 11f
        value.typeface = Typeface.DEFAULT_BOLD
        value.setTextColor(Color.rgb(90, 220, 255))
        value.gravity = Gravity.END
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(value)

        val bar = SeekBar(this)
        bar.max = 100
        bar.progress = (((get() - lo) / (hi - lo)) * 100f).toInt().coerceIn(0, 100)
        bar.setPadding(dp(8), dp(4), dp(8), dp(4))
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                val v = lo + p / 100f * (hi - lo)
                value.text = fmt(v)
                if (fromUser) {
                    set(v)
                    pad.invalidate()
                    livePush()
                }
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.addView(head)
        box.addView(bar)
        return box
    }

    private fun compactCurve(cfg: StickCfg): LinearLayout {
        val cur = cfg.curve
        val idx = curveNames.indexOfFirst { kotlin.math.abs(it.second - cur) < 0.05f }
        val labels = curveNames.map { it.first }.toMutableList()
        if (idx < 0) labels.add("Personalizada")
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, labels).also {
            it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        sp.setSelection(if (idx >= 0) idx else labels.size - 1, false)
        var first = true
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, pos: Int, id: Long) {
                if (first) {
                    first = false
                    return
                }
                if (pos < curveNames.size) {
                    cfg.curve = curveNames[pos].second
                    pad.invalidate()
                    livePush()
                }
            }
            override fun onNothingSelected(parent: AdapterView<*>) {}
        }
        val title = TextView(this)
        title.text = "Curva de resposta"
        title.textSize = 11f
        title.setTextColor(Color.WHITE)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.addView(title)
        box.addView(sp)
        return box
    }

    /**
     * Abre o painel do analógico (esquerdo ou direito). Cada analógico tem os seus próprios
     * valores. As mudanças já valem no motor enquanto você mexe; "Salvar" grava no perfil e
     * fechar sem salvar volta ao que estava. "Padrão" restaura os valores de fábrica.
     */
    private fun showStickCard(left: Boolean, original: StickCfg? = null) {
        val tag = if (left) "LS" else "RS"
        val cfg = if (left) profile.left else profile.right
        if (original == null && stickTag == tag) {   // tocar de novo no mesmo analógico fecha
            closeStickCard(false)
            return
        }
        if (original == null && stickCfgOpen != null) closeStickCard(false)
        val backup = original ?: cfg.copy()
        stickTag = tag
        stickCfgOpen = cfg
        stickBackup = backup

        popupHost.removeAllViews()
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(10), dp(8), dp(10), dp(10))
        val bg = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.rgb(22, 18, 52), Color.rgb(12, 14, 36))
        )
        bg.cornerRadius = dp(16).toFloat()
        bg.setStroke(dp(2), Color.rgb(112, 84, 255))
        card.background = bg

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val ttl = heading(if (left) "🕹  Analógico Esquerdo" else "🕹  Analógico Direito")
        ttl.textSize = 13f
        head.addView(ttl, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val x = TextView(this)
        x.text = "✕"
        x.textSize = 18f
        x.setTextColor(Color.rgb(200, 190, 255))
        x.setPadding(dp(10), dp(2), dp(2), dp(2))
        x.setOnClickListener { closeStickCard(false) }
        head.addView(x)
        card.addView(head)

        val gap = dp(10)
        val pct: (Float) -> String = { "%.0f%%".format(it * 100f) }

        val row1 = LinearLayout(this)
        row1.orientation = LinearLayout.HORIZONTAL
        row1.setPadding(0, dp(4), 0, 0)
        val l1 = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        l1.marginEnd = gap
        row1.addView(compactSlider("Zona morta", 0f, 0.5f, { cfg.deadzone }, { cfg.deadzone = it }, pct), l1)
        row1.addView(
            compactSlider("Zona máxima", 0.5f, 1f, { cfg.maxZone }, { cfg.maxZone = it }, pct),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        card.addView(row1)

        val row2 = LinearLayout(this)
        row2.orientation = LinearLayout.HORIZONTAL
        row2.setPadding(0, dp(6), 0, 0)
        val l2 = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        l2.marginEnd = gap
        row2.addView(compactSlider("Sensibilidade", 0.5f, 1.5f, { cfg.sens }, { cfg.sens = it }, pct), l2)
        row2.addView(compactCurve(cfg), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        card.addView(row2)

        val btns = LinearLayout(this)
        btns.orientation = LinearLayout.HORIZONTAL
        btns.setPadding(0, dp(8), 0, 0)
        val reset = Button(this)
        reset.text = "↺  Padrão"
        reset.setOnClickListener {
            val d = StickCfg()
            cfg.deadzone = d.deadzone
            cfg.curve = d.curve
            cfg.sens = d.sens
            cfg.maxZone = d.maxZone
            pushEngine()
            pad.invalidate()
            showStickCard(left, backup)
        }
        val save = Button(this)
        save.text = "💾  Salvar"
        save.setOnClickListener { closeStickCard(true) }
        val bl = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        bl.marginEnd = gap
        btns.addView(reset, bl)
        btns.addView(save, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        card.addView(btns)

        styleTree(card)
        popupHost.addView(card, FrameLayout.LayoutParams(dp(252), ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START))
        popupHost.visibility = View.VISIBLE
        card.visibility = View.INVISIBLE
        pad.selected = tag
        pad.invalidate()
        // Só dá para posicionar depois que o painel foi medido.
        card.viewTreeObserver.addOnGlobalLayoutListener(object : ViewTreeObserver.OnGlobalLayoutListener {
            override fun onGlobalLayout() {
                card.viewTreeObserver.removeOnGlobalLayoutListener(this)
                placeStickCard(card, tag, left)
            }
        })
    }

    /** Põe o painel ao lado do analógico, sem sair da área do controle, e anima a entrada. */
    private fun placeStickCard(card: View, tag: String, left: Boolean) {
        val r = pad.stickRect(tag)
        val pw = popupHost.width
        val ph = popupHost.height
        val cw = card.width
        val ch = card.height
        val m = dp(6)
        var x = (pw - cw) / 2
        var y = (ph - ch) / 2
        if (r != null) {
            val gap = dp(12)
            x = if (left) (r.left - gap - cw).toInt() else (r.right + gap).toInt()
            y = (r.centerY() - ch / 2f).toInt()
        }
        x = x.coerceIn(m, maxOf(m, pw - cw - m))
        y = y.coerceIn(m, maxOf(m, ph - ch - m))
        card.x = x.toFloat()
        card.y = y.toFloat()
        if (r != null) {
            card.pivotX = (r.centerX() - x).coerceIn(0f, cw.toFloat())
            card.pivotY = (r.centerY() - y).coerceIn(0f, ch.toFloat())
        }
        pad.link = PointF(if (left) x + cw.toFloat() else x.toFloat(), y + ch / 2f)
        pad.invalidate()
        card.alpha = 0f
        card.scaleX = 0.82f
        card.scaleY = 0.82f
        card.visibility = View.VISIBLE
        card.animate()
            .alpha(1f)
            .scaleX(1f)
            .scaleY(1f)
            .setDuration(200)
            .setInterpolator(DecelerateInterpolator())
            .start()
    }

    /** Fecha o painel do analógico. save = true grava no perfil; false volta ao que estava. */
    private fun closeStickCard(save: Boolean) {
        val cfg = stickCfgOpen
        val backup = stickBackup
        if (cfg != null && backup != null && !save) {
            cfg.deadzone = backup.deadzone
            cfg.curve = backup.curve
            cfg.sens = backup.sens
            cfg.maxZone = backup.maxZone
        }
        stickTag = null
        stickCfgOpen = null
        stickBackup = null
        pad.selected = null
        pad.link = null
        pad.invalidate()
        handler.removeCallbacks(livePushRunnable)
        if (save) {
            store.save(profile)
            Toast.makeText(this, "Analógico salvo no perfil \"${profile.name}\".", Toast.LENGTH_SHORT).show()
        }
        pushEngine()

        val card: View? = if (popupHost.childCount > 0) popupHost.getChildAt(0) else null
        if (card == null) {
            popupHost.visibility = View.GONE
        } else {
            card.animate()
                .alpha(0f)
                .scaleX(0.9f)
                .scaleY(0.9f)
                .setDuration(140)
                .withEndAction {
                    if (popupHost.childCount > 0 && popupHost.getChildAt(0) === card) {
                        popupHost.removeAllViews()
                        popupHost.visibility = View.GONE
                    }
                }
                .start()
        }
        if (save) buildPanel()   // as abas passam a mostrar os valores salvos
    }

    private fun showTriggerCard(left: Boolean) {
        val cfg = if (left) profile.lt else profile.rt
        showCard(if (left) "🎚  Gatilho L2" else "🎚  Gatilho R2", left) { card ->
            card.addView(triggerStartSlider("Zona morta inicial", { cfg.start }) { cfg.start = it })
            card.addView(triggerMaxSlider("Chega ao máximo em", { cfg.max }) { cfg.max = it })
            card.addView(curveDropdown("Curva de resposta", { cfg.curve }) { cfg.curve = it })
            card.addView(cardButtons {
                cfg.start = 0f
                cfg.max = 1f
                cfg.curve = 1f
                store.save(profile)
                pushEngine()
                pad.invalidate()
                showTriggerCard(left)
            })
        }
    }

    private fun showButtonCard(code: Int) {
        val leftSide = code == KeyEvent.KEYCODE_BUTTON_L1 || code == KeyEvent.KEYCODE_BUTTON_L2 ||
            code == KeyEvent.KEYCODE_BUTTON_SELECT ||
            code in KeyEvent.KEYCODE_DPAD_UP..KeyEvent.KEYCODE_DPAD_RIGHT
        showCard("🎯  " + buttonName(code), leftSide) { card ->
            val mapped = profile.remap[code]
            card.addView(label(if (mapped == null) "Sem remapeamento." else "Remapeado para ${buttonName(mapped)}."))
            val remap = Button(this)
            remap.text = "🔁  Remapear este botão"
            remap.setOnClickListener {
                closeCard()
                startRemapFor(code)
            }
            card.addView(remap)
            if (mapped != null) {
                val undo = Button(this)
                undo.text = "↺  Desfazer remapeamento"
                undo.setOnClickListener {
                    profile.remap.remove(code)
                    refreshRemapInfo()
                    closeCard()
                }
                card.addView(undo)
            }
        }
    }

    /** Remapear a partir do botão tocado no desenho: falta só escolher o destino. */
    private fun startRemapFor(code: Int) {
        if (step != Step.IDLE) return
        step = Step.TARGET
        source = code
        remapBtn.text = "Cancelar"
        remapInfo.text = "${buttonName(code)} vai virar qual botão? Toque no botão de destino no desenho " +
            "(ou aperte no controle, com o motor desligado). Toque no mesmo botão para desfazer."
        Toast.makeText(this, "Agora toque no botão de destino.", Toast.LENGTH_LONG).show()
    }

    // Lista de curvas com nome. 1.0 = linear; acima disso o centro fica mais suave.
    private val curveNames = listOf("Linear" to 1.0f, "Suave" to 1.5f, "Precisão" to 2.2f, "Agressiva" to 0.7f)

    private fun curveDropdown(name: String, get: () -> Float, set: (Float) -> Unit): LinearLayout {
        val cur = get()
        val idx = curveNames.indexOfFirst { kotlin.math.abs(it.second - cur) < 0.05f }
        val labels = curveNames.map { it.first }.toMutableList()
        if (idx < 0) labels.add("Personalizada (" + "%.2f".format(cur) + ")")
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, labels).also {
            it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        sp.setSelection(if (idx >= 0) idx else labels.size - 1, false)
        var first = true
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, pos: Int, id: Long) {
                if (first) {
                    first = false
                    return
                }
                if (pos < curveNames.size) {
                    set(curveNames[pos].second)
                    store.save(profile)
                    pushEngine()
                    pad.invalidate()
                }
            }
            override fun onNothingSelected(parent: AdapterView<*>) {}
        }
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(0, dp(6), 0, dp(6))
        box.addView(label(name))
        box.addView(sp)
        return box
    }

    private fun sensSlider(name: String, get: () -> Float, set: (Float) -> Unit) =
        slider(name, ((get() - 0.5f) * 100f).toInt().coerceIn(0, 100),
            { "%.0f%%".format((0.5f + it / 100f) * 100f) }) { set(0.5f + it / 100f) }

    // ------------------------------------------------------------------
    //  Painel da direita: três abas
    // ------------------------------------------------------------------

    private fun buildPanel() {
        panelPerfis.removeAllViews()
        panelLed.removeAllViews()
        panelAdv.removeAllViews()
        panel = panelPerfis
        buildPerfisTab()
        panel = panelLed
        buildLedTab()
        panel = panelAdv
        buildAdvTab()
        styleTree(panelPerfis)
        styleTree(panelLed)
        styleTree(panelAdv)
        selectTab(currentTab)
        refreshDots()
        refreshConn()
    }

    private fun buildPerfisTab() {
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(heading("📁  Perfis"), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val plus = Button(this)
        plus.text = "+"
        plus.setOnClickListener { askNewProfile() }
        head.addView(plus, LinearLayout.LayoutParams(dp(52), dp(42)))
        panel.addView(head)

        val names = store.names()
        panel.addView(Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_item, names).also {
                it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            }
            setSelection(names.indexOf(profile.name).coerceAtLeast(0), false)
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>, view: View?, pos: Int, id: Long) {
                    val n = names[pos]
                    if (n != profile.name) switchProfile(n)
                }
                override fun onNothingSelected(parent: AdapterView<*>) {}
            }
        })
        val save = Button(this)
        save.text = "💾  Salvar Perfil"
        save.setOnClickListener {
            store.save(profile)
            Toast.makeText(this, "Perfil \"${profile.name}\" salvo.", Toast.LENGTH_SHORT).show()
        }
        panel.addView(save)
        val del = Button(this)
        del.text = "🗑  Excluir Perfil"
        del.tag = "danger"
        del.setOnClickListener { askDeleteProfile() }
        panel.addView(del)

        panel.addView(heading("\n⚙  Configurações Gerais"))
        panel.addView(zoneSlider("Zona morta dos analógicos", { profile.left.deadzone }) {
            profile.left.deadzone = it
            profile.right.deadzone = it
        })
        panel.addView(curveDropdown("Curva de resposta", { profile.left.curve }) {
            profile.left.curve = it
            profile.right.curve = it
        })
        panel.addView(triggerStartSlider("Zona morta dos gatilhos", { profile.lt.start }) {
            profile.lt.start = it
            profile.rt.start = it
        })
        panel.addView(CheckBox(this).apply {
            text = "Inverter eixo Y (os dois analógicos)"
            setTextColor(Color.WHITE)
            isChecked = profile.invertY
            setOnCheckedChangeListener { _, checked ->
                profile.invertY = checked
                store.save(profile)
                pushEngine()
                pad.invalidate()
            }
        })
        panel.addView(label("Dica: toque em um analógico, gatilho ou botão do controle desenhado para ajustar só ele.").apply { textSize = 12f })
    }

    private fun buildLedTab() {
        // ---- LED ----
        panel.addView(label("\nLED do controle (experimental)").apply { textSize = 16f; tag = "h" })
        panel.addView(CheckBox(this).apply {
            text = "Usar cor personalizada"
            setTextColor(Color.WHITE)
            isChecked = profile.led
            setOnCheckedChangeListener { _, checked ->
                profile.led = checked
                store.save(profile)
                if (checked) applyLed() else {
                    LedService.stop(this@MainActivity)
                    LedCtl.release()
                    ledInfo.text = "Desligado: o controle voltou à cor padrão."
                }
                refreshDots()
            }
        })
        ledSwatch = label("   ").apply { textSize = 22f }
        panel.addView(ledSwatch)
        panel.addView(ledSlider("Vermelho", 0, { profile.ledR }) { profile.ledR = it })
        panel.addView(ledSlider("Verde", 1, { profile.ledG }) { profile.ledG = it })
        panel.addView(ledSlider("Azul", 2, { profile.ledB }) { profile.ledB = it })
        panel.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            val presets = listOf(
                "Verm." to Triple(255, 0, 0), "Verde" to Triple(0, 255, 0), "Azul" to Triple(0, 80, 255),
                "Roxo" to Triple(160, 0, 255), "Branco" to Triple(255, 255, 255)
            )
            for ((n, c) in presets) {
                addView(Button(this@MainActivity).apply {
                    text = n
                    textSize = 11f
                    setPadding(4, 0, 4, 0)
                    setOnClickListener { setLedColor(c.first, c.second, c.third) }
                }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            }
        })
        ledInfo = label("Mexa nos controles e solte para aplicar. A cor vale enquanto o app estiver aberto ou em segundo plano. O resultado aparece aqui.").apply { textSize = 12f }
        panel.addView(ledInfo)
        updateSwatch()
    }

    private fun buildAdvTab() {
        status = label(if (device != null) status.text.toString() else "Conecte o controle e mexa em qualquer botão.")
        panel.addView(status)

        // ---- Motor (vale dentro dos jogos) ----
        panel.addView(label("\nMotor (vale dentro dos jogos)").apply { textSize = 16f; tag = "h" })
        engineStatus = label(engineText)
        panel.addView(engineStatus)
        panel.addView(Button(this).apply {
            text = "Ativar motor (Shizuku)"
            setOnClickListener { startEngine() }
        })
        panel.addView(Button(this).apply {
            text = "Desativar motor"
            setOnClickListener { stopEngine() }
        })
        panel.addView(label("Com o motor ativo, o PS4 passa por aqui e os ajustes valem em qualquer jogo. Ative antes de abrir o jogo.").apply { textSize = 12f })


        // ---- Gatilhos ----
        panel.addView(label("\nGatilho L2").apply { textSize = 16f; tag = "h" })
        panel.addView(triggerStartSlider("Zona morta inicial", { profile.lt.start }) { profile.lt.start = it })
        panel.addView(triggerMaxSlider("Chega ao máximo em", { profile.lt.max }) { profile.lt.max = it })
        panel.addView(curveSlider("Curva (1.0 = linear)", { profile.lt.curve }) { profile.lt.curve = it })

        panel.addView(label("\nGatilho R2").apply { textSize = 16f; tag = "h" })
        panel.addView(triggerStartSlider("Zona morta inicial", { profile.rt.start }) { profile.rt.start = it })
        panel.addView(triggerMaxSlider("Chega ao máximo em", { profile.rt.max }) { profile.rt.max = it })
        panel.addView(curveSlider("Curva (1.0 = linear)", { profile.rt.curve }) { profile.rt.curve = it })

        // ---- Vibração ----
        panel.addView(label("\nVibração").apply { textSize = 16f; tag = "h" })
        panel.addView(slider("Intensidade", (profile.vibration * 100).toInt(),
            { "$it%" }) {
            profile.vibration = it / 100f
        })
        panel.addView(Button(this).apply {
            text = "Testar vibração"
            setOnClickListener { testVibration() }
        })


        // ---- Remapeamento ----
        panel.addView(label("\nRemapeamento de botões").apply { textSize = 16f; tag = "h" })
        remapBtn = Button(this).apply {
            text = "Remapear um botão"
            setOnClickListener { toggleRemap() }
        }
        panel.addView(remapBtn)
        panel.addView(Button(this).apply {
            text = "Limpar remapeamentos"
            setOnClickListener {
                profile.remap.clear()
                store.save(profile)
                pushEngine()
                step = Step.IDLE
                remapBtn.text = "Remapear um botão"
                pad.state.pressed.clear()
                hatHeld.clear()
                refreshRemapInfo()
                pad.invalidate()
            }
        })
        remapInfo = label("")
        panel.addView(remapInfo)
        refreshRemapInfo()

        panel.addView(Button(this).apply {
            text = "Diagnóstico (Shizuku)"
            setOnClickListener { startActivity(Intent(this@MainActivity, DiagActivity::class.java)) }
        })
    }

    // ---- LED ----

    private fun updateSwatch() {
        ledSwatch.setBackgroundColor(Color.rgb(profile.ledR, profile.ledG, profile.ledB))
    }

    /** Slider 0..255 de uma cor do LED. O índice guarda a barra para os atalhos de cor poderem mexer nela. */
    private fun ledSlider(name: String, idx: Int, get: () -> Int, set: (Int) -> Unit): LinearLayout {
        val title = label("$name: ${get()}")
        val bar = SeekBar(this).apply {
            max = 255
            progress = get()
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                    title.text = "$name: $p"
                    set(p)
                    updateSwatch()
                }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {
                    profile.led = true
                    store.save(profile)
                    applyLed()
                }
            })
        }
        ledBars[idx] = bar
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 8, 0, 8)
            addView(title)
            addView(bar)
        }
    }

    private fun setLedColor(r: Int, g: Int, b: Int) {
        profile.ledR = r; profile.ledG = g; profile.ledB = b
        profile.led = true
        ledBars[0]?.progress = r
        ledBars[1]?.progress = g
        ledBars[2]?.progress = b
        updateSwatch()
        store.save(profile)
        refreshDots()
        applyLed()
    }

    /** Aplica a cor agora, pela API de luzes do Android (não precisa de Shizuku). */
    private fun applyLed() {
        if (!profile.led) return
        askNotificationPermission()
        LedService.start(this)   // mantém o app vivo para a cor não apagar
        val r = profile.ledR; val g = profile.ledG; val b = profile.ledB
        thread {
            val res = LedCtl.set(r, g, b)
            runOnUiThread { ledInfo.text = res }
        }
    }

    /** Android 13+: sem essa permissão a notificação fica escondida, mas o serviço funciona do mesmo jeito. */
    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) !=
            android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 77)
        }
    }

    // ---- Perfis ----

    private fun switchProfile(name: String, saveCurrent: Boolean = true) {
        if (stickCfgOpen != null) closeStickCard(false)
        if (saveCurrent) store.save(profile)
        profile = store.load(name)
        store.setActive(name)
        pad.profile = profile
        step = Step.IDLE
        pad.state.pressed.clear()
        hatHeld.clear()
        buildPanel()
        pushEngine()
        if (profile.led) applyLed() else {
            LedService.stop(this)
            LedCtl.release()
        }
        pad.invalidate()
    }

    private fun askNewProfile() {
        val input = EditText(this).apply { hint = "Nome do perfil"; setSingleLine() }
        AlertDialog.Builder(this)
            .setTitle("Novo perfil")
            .setMessage("Ele começa com os mesmos ajustes do perfil atual.")
            .setView(input)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Criar") { _, _ ->
                val n = input.text.toString().replace("\n", " ").trim().take(24)
                when {
                    n.isEmpty() -> Toast.makeText(this, "Digite um nome.", Toast.LENGTH_SHORT).show()
                    n in store.names() -> Toast.makeText(this, "Já existe um perfil com esse nome.", Toast.LENGTH_SHORT).show()
                    else -> {
                        val copy = profile.snapshot().also { it.name = n }
                        store.save(copy)
                        switchProfile(n)
                    }
                }
            }
            .show()
    }

    private fun askDeleteProfile() {
        if (store.names().size <= 1) {
            Toast.makeText(this, "Precisa existir pelo menos um perfil.", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Excluir \"${profile.name}\"?")
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Excluir") { _, _ ->
                store.delete(profile.name)
                switchProfile(store.activeName(), saveCurrent = false)
            }
            .show()
    }

    override fun onResume() {
        super.onResume()
        refreshConn()
        handler.post(statusTick)
    }

    override fun onPause() {
        handler.removeCallbacks(statusTick)
        super.onPause()
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permListener)
        (getSystemService(Context.INPUT_SERVICE) as InputManager).unregisterInputDeviceListener(padListener)
        super.onDestroy()
    }

    // ---- Motor ----

    private fun applyEngineStatus(s: String) {
        engineOn = s.startsWith("RODANDO")
        engineText = when {
            s.startsWith("SEM_SHIZUKU") -> "Motor: parado. O Shizuku não está ativo (abra o app Shizuku e toque em Iniciar)."
            s.startsWith("SEM_PERMISSAO") -> "Motor: parado. Toque em Ativar e aceite a permissão do Shizuku."
            s.startsWith("PARADO") -> {
                val why = s.removePrefix("PARADO").trim()
                if (why.isEmpty()) "Motor: parado." else "Motor: parado.\n$why"
            }
            s.startsWith("RODANDO") -> "Motor: ativo.\n" + s.removePrefix("RODANDO").trim()
            else -> "Motor: $s"
        }
        engineStatus.text = engineText
    }

    private fun snapshot(): Profile = profile.snapshot()

    private fun pushEngine() {
        if (!engineOn) return
        val snap = snapshot()
        thread { PadEngineCtl.pushConfig(snap) }
    }

    private fun startEngine() {
        if (!PadEngineCtl.alive()) {
            Toast.makeText(this, "Shizuku não está ativo. Abra o app Shizuku e toque em Iniciar.", Toast.LENGTH_LONG).show()
            return
        }
        if (!PadEngineCtl.granted()) {
            try {
                if (Shizuku.shouldShowRequestPermissionRationale()) {
                    Toast.makeText(this, "Permissão negada antes. Libere o DS4 Mapper dentro do app Shizuku.", Toast.LENGTH_LONG).show()
                } else {
                    Shizuku.requestPermission(1002)
                }
            } catch (t: Throwable) {
                Toast.makeText(this, "Erro: $t", Toast.LENGTH_LONG).show()
            }
            return
        }
        engineStatus.text = "Motor: iniciando..."
        val apk = applicationInfo.sourceDir
        val snap = snapshot()
        thread {
            PadEngineCtl.start(apk, snap)
            Thread.sleep(2500)
            val s = PadEngineCtl.status()
            runOnUiThread { applyEngineStatus(s) }
        }
    }

    private fun stopEngine() {
        if (!PadEngineCtl.alive() || !PadEngineCtl.granted()) {
            applyEngineStatus(PadEngineCtl.status())
            return
        }
        engineStatus.text = "Motor: parando..."
        thread {
            PadEngineCtl.stop()
            val s = PadEngineCtl.status()
            runOnUiThread { applyEngineStatus(s) }
        }
    }

    private fun label(t: String) = TextView(this).apply { text = t; setTextColor(Color.WHITE) }

    private fun slider(name: String, start: Int, fmt: (Int) -> String, onChange: (Int) -> Unit): LinearLayout {
        val title = label("$name: ${fmt(start)}")
        val bar = SeekBar(this).apply {
            max = 100
            progress = start
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                    title.text = "$name: ${fmt(p)}"
                    onChange(p)
                    pad.invalidate()
                }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) { store.save(profile); pushEngine() }
            })
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 16, 0, 16)
            addView(title)
            addView(bar)
        }
    }

    private fun zoneSlider(name: String, get: () -> Float, set: (Float) -> Unit) =
        slider(name, (get() / 0.5f * 100).toInt().coerceIn(0, 100),
            { "%.0f%%".format(it / 100f * 0.5f * 100) }) { set(it / 100f * 0.5f) }

    private fun curveSlider(name: String, get: () -> Float, set: (Float) -> Unit) =
        slider(name, ((get() - 0.5f) / 2.5f * 100).toInt().coerceIn(0, 100),
            { "%.2f".format(0.5f + it / 100f * 2.5f) }) { set(0.5f + it / 100f * 2.5f) }

    // Zona morta inicial do gatilho: 0% a 40%.
    private fun triggerStartSlider(name: String, get: () -> Float, set: (Float) -> Unit) =
        slider(name, (get() / 0.4f * 100).toInt().coerceIn(0, 100),
            { "%.0f%%".format(it / 100f * 0.4f * 100) }) { set(it / 100f * 0.4f) }

    // Onde o gatilho chega ao máximo: 50% a 100% do curso (menos = curso mais curto).
    private fun triggerMaxSlider(name: String, get: () -> Float, set: (Float) -> Unit) =
        slider(name, ((get() - 0.5f) / 0.5f * 100).toInt().coerceIn(0, 100),
            { "%.0f%% do curso".format((0.5f + it / 100f * 0.5f) * 100) }) { set(0.5f + it / 100f * 0.5f) }

    // ---- Remapeamento: 1) aperte o botão a trocar  2) aperte o botão que ele deve virar ----

    private fun toggleRemap() {
        if (step == Step.IDLE) {
            step = Step.SOURCE
            remapBtn.text = "Cancelar"
            remapInfo.text = "Passo 1: toque no desenho do controle (ou aperte no controle, com o motor desligado) no botão que você quer trocar."
        } else {
            step = Step.IDLE
            remapBtn.text = "Remapear um botão"
            refreshRemapInfo()
        }
    }

    private fun handleRemapPress(code: Int) {
        when (step) {
            Step.SOURCE -> {
                source = code
                step = Step.TARGET
                remapInfo.text = "Passo 2: ${buttonName(code)} vai virar qual botão? Toque no botão de destino no desenho.\n(Aperte o mesmo botão para desfazer a troca.)"
            }
            Step.TARGET -> {
                if (code == source) profile.remap.remove(source) else profile.remap[source] = code
                store.save(profile)
                pushEngine()
                step = Step.IDLE
                remapBtn.text = "Remapear um botão"
                pad.state.pressed.clear()
                hatHeld.clear()
                refreshRemapInfo()
                pad.invalidate()
            }
            Step.IDLE -> {}
        }
    }

    private fun refreshRemapInfo() {
        remapInfo.text = if (profile.remap.isEmpty()) {
            "Nenhum remapeamento. Aperte um botão para ver como fica."
        } else {
            profile.remap.entries.joinToString("\n") {
                "${buttonName(it.key)} → ${buttonName(it.value)}"
            }
        }
    }

    // ---- Entrada do controle ----

    private fun handleHat(hx: Float, hy: Float) {
        if (hx == lastHx && hy == lastHy) return
        lastHx = hx
        lastHy = hy
        pad.state.pressed.removeAll(hatHeld)
        hatHeld.clear()
        val raw = listOfNotNull(
            if (hy < -0.5f) KeyEvent.KEYCODE_DPAD_UP else null,
            if (hy > 0.5f) KeyEvent.KEYCODE_DPAD_DOWN else null,
            if (hx < -0.5f) KeyEvent.KEYCODE_DPAD_LEFT else null,
            if (hx > 0.5f) KeyEvent.KEYCODE_DPAD_RIGHT else null
        )
        if (step != Step.IDLE) {
            val first = raw.firstOrNull()
            if (first != null) handleRemapPress(first)
        } else {
            for (code in raw) {
                val mapped = if (pad.passthrough) code else profile.map(code)
                hatHeld.add(mapped)
                pad.state.pressed.add(mapped)
            }
        }
    }

    override fun dispatchGenericMotionEvent(e: MotionEvent): Boolean {
        if (e.isFromSource(InputDevice.SOURCE_JOYSTICK) && e.action == MotionEvent.ACTION_MOVE) {
            pad.passthrough = e.device?.name == PadEngineCtl.DEVICE_NAME
            val s = pad.state
            s.lx = e.getAxisValue(MotionEvent.AXIS_X)
            s.ly = e.getAxisValue(MotionEvent.AXIS_Y)
            s.rx = e.getAxisValue(MotionEvent.AXIS_Z)
            s.ry = e.getAxisValue(MotionEvent.AXIS_RZ)
            s.lt = max(e.getAxisValue(MotionEvent.AXIS_LTRIGGER), e.getAxisValue(MotionEvent.AXIS_BRAKE))
            s.rt = max(e.getAxisValue(MotionEvent.AXIS_RTRIGGER), e.getAxisValue(MotionEvent.AXIS_GAS))
            handleHat(e.getAxisValue(MotionEvent.AXIS_HAT_X), e.getAxisValue(MotionEvent.AXIS_HAT_Y))
            setDevice(e.device)
            pad.invalidate()
            return true
        }
        return super.dispatchGenericMotionEvent(e)
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        val fromPad = e.isFromSource(InputDevice.SOURCE_GAMEPAD) || e.isFromSource(InputDevice.SOURCE_DPAD)
        val isPadKey = KeyEvent.isGamepadButton(e.keyCode) ||
            e.keyCode in KeyEvent.KEYCODE_DPAD_UP..KeyEvent.KEYCODE_DPAD_RIGHT
        if (!fromPad || !isPadKey) return super.dispatchKeyEvent(e)

        setDevice(e.device)
        pad.passthrough = e.device?.name == PadEngineCtl.DEVICE_NAME

        if (step != Step.IDLE) {
            if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0 && !engineOn) handleRemapPress(e.keyCode)
            return true
        }

        val mapped = if (pad.passthrough) e.keyCode else profile.map(e.keyCode)
        if (e.action == KeyEvent.ACTION_DOWN) pad.state.pressed.add(mapped)
        else if (e.action == KeyEvent.ACTION_UP) pad.state.pressed.remove(mapped)
        pad.invalidate()
        return true
    }

    private fun setDevice(d: InputDevice?) {
        if (d == null || d.id == device?.id) return
        device = d
        var info = "Controle: ${d.name}"
        if (Build.VERSION.SDK_INT >= 31) {
            val b = d.batteryState
            if (b.isPresent && !b.capacity.isNaN()) info += "\nBateria: ${(b.capacity * 100).toInt()}%"
        }
        status.text = info
        refreshConn()
    }

    private fun testVibration() {
        val d = device ?: return
        val amp = max(1, (profile.vibration * 255).toInt())
        if (Build.VERSION.SDK_INT >= 31) {
            val v = d.vibratorManager.defaultVibrator
            if (v.hasVibrator()) v.vibrate(VibrationEffect.createOneShot(400, amp))
        } else {
            @Suppress("DEPRECATION")
            d.vibrator.vibrate(400)
        }
    }
}
